# hello_world.py
print("Hello World! I am Nidhi Singh")
